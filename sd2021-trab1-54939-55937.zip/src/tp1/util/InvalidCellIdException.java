package tp1.util;

public class InvalidCellIdException extends Exception {

	public InvalidCellIdException(String msg) {
		super(msg);
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = -2214302489926561405L;
}